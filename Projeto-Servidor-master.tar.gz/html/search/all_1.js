var searchData=
[
  ['projeto_2dservidor',['Projeto-Servidor',['../md__r_e_a_d_m_e.html',1,'']]],
  ['putdata',['putData',['../class_main_window.html#afdfeb13ec363b0eb8ecacaf0aa13b605',1,'MainWindow']]]
];
