var searchData=
[
  ['putdata',['putData',['../class_main_window.html#afdfeb13ec363b0eb8ecacaf0aa13b605',1,'MainWindow']]]
];
