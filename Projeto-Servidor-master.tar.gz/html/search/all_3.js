var searchData=
[
  ['tcpconnect',['tcpConnect',['../class_main_window.html#ac5b669957c442b6eb68573dacfce33e1',1,'MainWindow']]],
  ['tcpdisconnect',['tcpDisconnect',['../class_main_window.html#a4d22c4c7afc7ba0a2fa4c70515c85dda',1,'MainWindow']]]
];
